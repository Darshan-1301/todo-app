# Todo App with Calendar and Project Integration

A modern web-based todo application that includes:
- Drag and drop functionality for tasks
- Calendar integration for task scheduling
- Project management with drag and drop
- Clean and responsive UI

## Features

- Add, edit, and delete tasks
- Drag and drop tasks between different sections
- Calendar integration to schedule tasks
- Project management with drag and drop
- Responsive design that works on all devices

## Technologies Used

- HTML5
- CSS3
- JavaScript
- FullCalendar.js (for calendar functionality)

## Getting Started

1. Clone this repository
2. Open `index.html` in a modern web browser
3. Start using the application

## Usage

- Click the "+" button or press Enter to add a new task
- Drag tasks between different sections
- Click the edit button (pencil icon) to modify a task
- Click the delete button (trash icon) to remove a task
- Use the calendar to schedule tasks
- Drag and drop projects to reorder them
