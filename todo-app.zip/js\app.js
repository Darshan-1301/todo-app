document.addEventListener('DOMContentLoaded', () => {
    const taskInput = document.getElementById('task-input');
    const addTaskBtn = document.getElementById('add-task-btn');
    const taskList = document.getElementById('task-list');
    const projectsList = document.getElementById('projects-list');

    // Initialize calendar
    const calendar = new FullCalendar.Calendar(document.getElementById('calendar'), {
        initialView: 'dayGridMonth',
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },
        selectable: true,
        select: function(info) {
            const taskName = prompt('Enter task name:');
            if (taskName) {
                addTask(taskName, info.startStr);
            }
        }
    });
    calendar.render();

    // Add task function
    function addTask(taskName, date = null) {
        const taskCard = document.createElement('div');
        taskCard.className = 'task-card';
        taskCard.draggable = true;
        taskCard.innerHTML = `
            <div class="task-header">
                <span class="task-title">${taskName}</span>
                <div class="task-actions">
                    <button class="edit-btn"><i class="fas fa-edit"></i></button>
                    <button class="delete-btn"><i class="fas fa-trash"></i></button>
                </div>
            </div>
            <div class="task-details">
                ${date ? `<p class="task-date">Due: ${new Date(date).toLocaleDateString()}</p>` : ''}
            </div>
        `;

        // Add drag and drop functionality
        taskCard.addEventListener('dragstart', (e) => {
            e.dataTransfer.setData('text/plain', taskCard.innerHTML);
            taskCard.classList.add('dragging');
        });

        taskCard.addEventListener('dragend', () => {
            taskCard.classList.remove('dragging');
        });

        // Add event listeners for buttons
        const deleteBtn = taskCard.querySelector('.delete-btn');
        deleteBtn.addEventListener('click', () => {
            taskCard.remove();
        });

        const editBtn = taskCard.querySelector('.edit-btn');
        editBtn.addEventListener('click', () => {
            const newTaskName = prompt('Edit task:', taskName);
            if (newTaskName) {
                taskCard.querySelector('.task-title').textContent = newTaskName;
            }
        });

        taskList.appendChild(taskCard);
    }

    // Add task button click handler
    addTaskBtn.addEventListener('click', () => {
        const taskName = taskInput.value.trim();
        if (taskName) {
            addTask(taskName);
            taskInput.value = '';
        }
    });

    // Add keyboard support for add task
    taskInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            addTaskBtn.click();
        }
    });

    // Drag and drop functionality for projects
    let draggedProject = null;

    projectsList.addEventListener('dragstart', (e) => {
        draggedProject = e.target;
        e.dataTransfer.setData('text/plain', draggedProject.innerHTML);
    });

    projectsList.addEventListener('dragover', (e) => {
        e.preventDefault();
        const afterElement = getDragAfterElement(projectsList, e.clientY);
        const draggable = document.querySelector('.dragging');
        if (afterElement == null) {
            projectsList.appendChild(draggedProject);
        } else {
            projectsList.insertBefore(draggedProject, afterElement);
        }
    });

    projectsList.addEventListener('dragend', () => {
        draggedProject = null;
    });

    // Helper function for drag and drop
    function getDragAfterElement(container, y) {
        const draggableElements = [...container.querySelectorAll('.project-item:not(.dragging)')];
        return draggableElements.reduce((closest, child) => {
            const box = child.getBoundingClientRect();
            const offset = y - box.top - box.height / 2;
            if (offset < 0 && offset > closest.offset) {
                return { offset: offset, element: child };
            } else {
                return closest;
            }
        }, { offset: Number.NEGATIVE_INFINITY }).element;
    }
});
